import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

final FlutterSecureStorage _storage = FlutterSecureStorage();
const _key = "ThemeLogic";

class ThemeLogic extends ChangeNotifier {
  int _themeIndex = 0; //system mode
  int get themeIndex => _themeIndex;

  Future readTheme() async {

    await Future.delayed(Duration(seconds: 1));
    String value = await _storage.read(key: _key) ?? "0";
    _themeIndex = int.parse(value); // default to system mode
    notifyListeners();
  }

  void setTheme(int index) {
    _themeIndex = index;
    _storage.write(key: _key, value: _themeIndex.toString());
    notifyListeners();
  }

  void changeToSystem() {
    _themeIndex = 0;
    _storage.write(key: _key, value: _themeIndex.toString());
    notifyListeners();
  }

  void changeToDark() {
    _themeIndex = 1;
    _storage.write(key: _key, value: _themeIndex.toString());
    notifyListeners();
  }

  void changeToLight() {
    _themeIndex = 2;
    _storage.write(key: _key, value: _themeIndex.toString());
    notifyListeners();
  }

  // bool _dark = false;
  // bool get dark => _dark;

  // void setDark(bool value){
  //   // _dark = value;
  //   notifyListeners();
  // }

  // void changeToDark(){
  //   _dark = true;
  //   notifyListeners();
  // }

  // void changeToLight(){
  //   _dark = false;
  //   notifyListeners();
  // }
}
