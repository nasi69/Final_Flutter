import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // const LoginScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Colors.white, body: _buildBody());
  }

  Widget _buildBody() {
    return Center(
      child: Container(
        constraints: BoxConstraints(maxWidth: 500),
        padding: EdgeInsets.all(20),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _builLogo(),
              SizedBox(height: 10),
              _buildEmailTextField(),
              SizedBox(height: 10),
              _buildPasswordTextField(),
              SizedBox(height: 10),
              _buildLoginButton(),
            ],
          ),
        ),
      ),
    );
  }

  final _img =
      "https://img.freepik.com/premium-photo/young-girl-wearing-yellow-tshirt-smiling-facing-camera-empty-space-isolated-bright-yellow_74379-2763.jpg?semt=ais_hybrid&w=740";

  Widget _builLogo() {
    return CircleAvatar(radius: 70, backgroundImage: NetworkImage(_img));
  }

  Widget _buildEmailTextField() {
    return TextField(
      keyboardType: TextInputType.emailAddress,
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.email),
        iconColor: Colors.grey.shade800,
        hintText: "Enter email",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(100)),
      ),
      textInputAction: TextInputAction.next,
    );
  }

  bool _hidePassword = true;

  Widget _buildPasswordTextField() {
    return TextField(
      decoration: InputDecoration(
        prefixIcon: Icon(Icons.key),
        iconColor: Colors.grey.shade800,
        hintText: "Enter password",
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(100)),
        suffixIcon: IconButton(
          onPressed: () {
            setState(() {
              _hidePassword = !_hidePassword;
            });
          },
          icon: Icon(_hidePassword ? Icons.visibility : Icons.visibility_off),
        ),
      ),
      textInputAction: TextInputAction.send,
      obscureText: _hidePassword,
    );
  }

  Widget _buildLoginButton() {
    return SizedBox(
      width: double.maxFinite,
      height: 50,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.orange,
          foregroundColor: Colors.white,
        ),
        onPressed: () {},
        child: Text("Login"),
      ),
    );
  }
}
