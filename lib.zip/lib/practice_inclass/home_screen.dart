import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  // const HomeScreen({super.key});

  final pic1 =
      "https://www.rogerebert.com/wp-content/uploads/2025/03/MV5BMjQ1MTYzZmItMTkzYy00NzdmLTlhYmMtMzk5YjhiOThmZDgwXkEyXkFqcGc@._V1_.jpg";
  final pic2 =
      "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b3/Blackpink_Ros%C3%A9_Rimowa_1.jpg/640px-Blackpink_Ros%C3%A9_Rimowa_1.jpg";

  final pic3 =
      "https://papers.co/wallpaper/papers.co-hv16-kpop-lisa-girl-blackpink-6-wallpaper.jpg";

  final img1 =
      "https://media2.firstshowing.net/firstshowing/img16/LastBullet3Mainposterbigimg599.jpg";

  final bg1 =
      "https://static.vecteezy.com/system/resources/thumbnails/039/666/301/small/ai-generated-abstract-vibrant-colorful-wave-background-for-wallpaper-presentation-photo.jpg";

  final gif1 =
      "https://mir-s3-cdn-cf.behance.net/project_modules/disp/223e6792880429.5e569ff84ebef.gif";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.black,
      appBar: _buildAppBar(),
      body: _buildBody(),
      drawer: _buildDrawer(),
      endDrawer: _buildEndDrawer(),
    );
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: Text("កម្មវិធីខ្មែរ", style: TextStyle(fontFamily: "FREE Hand")),
      // backgroundColor: Colors.pink,
      // foregroundColor: Colors.white,
      // flexibleSpace: Image.network(gif1, fit: BoxFit.cover),
    );
  }

  Widget _buildDrawer() {
    return Drawer(child: Image.network(pic2, fit: BoxFit.cover));
  }

  Widget _buildEndDrawer() {
    return Drawer(child: Image.network(pic3, fit: BoxFit.cover));
  }

  Widget _buildBody() {
    return Container(
      alignment: Alignment.center,
      // color: Colors.yellow.shade200,
      child: _buildCircleAvatar(),
    );
  }

  Widget _buildCircleAvatar(){
    return CircleAvatar(
      radius: 150,
      backgroundImage: NetworkImage(pic1),
    );
  }

  Widget _buildCircleImage(){
    return ClipOval(
      child: Image.network(pic1, width: 200, height: 200, fit: BoxFit.cover),
    );
  }

  Widget _buildRoundedImage() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Image.network(pic1, width: 200, height: 300, fit: BoxFit.cover),
    );
  }

  Widget _buildRoundedBox() {
    return Container(
      width: 150,
      height: 150,
      // color: Colors.pink,
      transform: Matrix4.rotationZ(0.3),
      transformAlignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.pink,
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(
          colors: [Colors.pink, Colors.indigo],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        boxShadow: [
          BoxShadow(
            offset: Offset(0, 0),
            color: Colors.blueGrey.withAlpha(185),
            blurRadius: 10,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Icon(CupertinoIcons.home, color: Colors.white, size: 80),
    );
  }

  Widget _buildContainer() {
    return Container(
      // padding: EdgeInsets.all(20),
      margin: EdgeInsets.all(20),
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 50),
      alignment: Alignment.topLeft,
      color: Colors.yellow,
      child: Container(width: 150, height: 200, color: Colors.purple),
    );
  }

  Widget _buildImage() {
    return Center(
      child: Image.network(
        img1,
        color: Colors.red,
        colorBlendMode: BlendMode.colorBurn,
      ),
    );
  }
}
