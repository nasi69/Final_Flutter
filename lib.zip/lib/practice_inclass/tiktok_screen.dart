import 'package:flutter/material.dart';
import 'photo_constant.dart';

class TiktokScreen extends StatefulWidget {
  const TiktokScreen({super.key});

  @override
  State<TiktokScreen> createState() => _TiktokScreenState();
}

class _TiktokScreenState extends State<TiktokScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.black,
      body: _buildBody(),
      // bottomNavigationBar: _buildAppBar(),
    );
  }

  Widget _buildAppBar() {
    return BottomAppBar(
      color: Colors.black,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.home, color: Colors.white70),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.search, color: Colors.white70),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.bookmark, color: Colors.white70),
          ),
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.more_horiz, color: Colors.white70),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    return Stack(
      alignment: Alignment.center,
      children: [
        _buildMainPageView(),
        Positioned(top: 20, child: _buildTopMenu()),
      ],
    );
  }

  Widget _buildTopMenu() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [_buildFollowingButton(), _buildForYouButton()],
    );
  }

  Widget _buildFollowingButton() {
    return TextButton(
      style: TextButton.styleFrom(
        foregroundColor: Colors.white,
        textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      onPressed: () {},
      child: Text("Following"),
    );
  }

  Widget _buildForYouButton() {
    return TextButton(
      style: TextButton.styleFrom(
        foregroundColor: Colors.white,
        textStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.normal),
      ),
      onPressed: () {},
      child: Text("For You"),
    );
  }

  Widget _buildMainPageView() {
    return PageView(
      children: [_buildFollowing(), _buildForYou()]);
  }

  Widget _buildFollowing() {
    return PageView.builder(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.vertical,
      itemCount: actorList.length,
      itemBuilder: (context, index) {
        final item = actorList[index];
        return Image.network(item, fit: BoxFit.cover);
      },
    );
  }

  Widget _buildForYou() {
    return PageView.builder(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.vertical,
      itemCount: imageList.length,
      itemBuilder: (context, index) {
        final item = imageList[index];
        return Image.network(item, fit: BoxFit.cover);
      },
    );
  }
}
