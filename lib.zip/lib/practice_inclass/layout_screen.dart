import 'package:flutter/material.dart';

import 'photo_constant.dart';

class LayoutScreen extends StatefulWidget {
  const LayoutScreen({super.key});

  @override
  State<LayoutScreen> createState() => _LayoutScreenState();
}

class _LayoutScreenState extends State<LayoutScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: _buildAppBar(), body: _buildBody());
  }

  AppBar _buildAppBar() {
    return AppBar(title: _buildTopMenu());
  }

  Widget _buildTopMenu() {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          _buildMenu("New Release"),
          _buildMenu("Popular TV Series"),
          _buildMenu("Best Movies"),
          _buildMenu("Sci-fi Movies"),
          _buildMenu("Horror Movies"),
          _buildMenu("Adventure Movies"),
          _buildMenu("Comedy Movies"),
        ],
      ),
    );
  }

  Widget _buildMenu(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5),
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.pink.shade300,
          foregroundColor: Colors.white,
        ),
        onPressed: () {},
        child: Text(title),
      ),
    );
  }

  Widget _buildBody() {
    return _buildActorGridView();
  }

  
  Widget _buildActorGridView() {
    return GridView.builder(
      // scrollDirection: Axis.horizontal,
      padding: EdgeInsets.all(5),
      physics: BouncingScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 2 / 3,
        crossAxisSpacing: 5,
        mainAxisSpacing: 5,
      ),
      itemCount: actorList.length,
      itemBuilder: (context, index) {
        final item = actorList[index];
        return ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Image.network(item, fit: BoxFit.cover),
        );
      },
    );
  }

  Widget _buildGridViewExtent() {
    return GridView.extent(
      scrollDirection: Axis.vertical,
      physics: BouncingScrollPhysics(),
      // crossAxisCount: 3,
      maxCrossAxisExtent: 150,
      childAspectRatio: 2 / 3,
      mainAxisSpacing: 5,
      crossAxisSpacing: 5,
      padding: EdgeInsets.all(5),
      children: [
        Container(color: Colors.pink, width: 100, height: 120),
        Container(color: Colors.blue, width: 180, height: 150),
        Container(color: Colors.yellow, width: 80, height: 150),
        Container(color: Colors.purple, width: 150, height: 200),
        Container(color: Colors.lime, width: 80, height: 150),
        Container(color: Colors.orange, width: 150, height: 200),
      ],
    );
  }

  Widget _buildGridViewCount() {
    return GridView.count(
      scrollDirection: Axis.vertical,
      physics: BouncingScrollPhysics(),
      crossAxisCount: 3,
      childAspectRatio: 2 / 3,
      mainAxisSpacing: 5,
      crossAxisSpacing: 5,
      padding: EdgeInsets.all(5),
      children: [
        Container(color: Colors.pink, width: 100, height: 120),
        Container(color: Colors.blue, width: 180, height: 150),
        Container(color: Colors.yellow, width: 80, height: 150),
        Container(color: Colors.purple, width: 150, height: 200),
        Container(color: Colors.lime, width: 80, height: 150),
        Container(color: Colors.orange, width: 150, height: 200),
      ],
    );
  }

  

  Widget _buildMovieListView() {
    return ListView.builder(
      physics: BouncingScrollPhysics(),
      itemCount: imageList.length,
      itemBuilder: (context, index) {
        final item = imageList[index];
        return Padding(
          padding: const EdgeInsets.all(5.0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: Image.network(item, fit: BoxFit.cover),
          ),
        );
      },
    );
  }

  Widget _buildHorListView() {
    return SizedBox(
      height: 300,
      child: ListView(
        scrollDirection: Axis.horizontal,
        physics: BouncingScrollPhysics(),
        children: [
          Container(color: Colors.pink, width: 100, height: 120),
          Container(color: Colors.blue, width: 180, height: 150),
          Container(color: Colors.yellow, width: 80, height: 150),
          Container(color: Colors.purple, width: 150, height: 200),
          Container(color: Colors.lime, width: 80, height: 150),
          Container(color: Colors.orange, width: 150, height: 200),
        ],
      ),
    );
  }

  Widget _buildListView() {
    return ListView(
      // scrollDirection: Axis.vertical, //default
      physics: BouncingScrollPhysics(),
      children: [
        Container(color: Colors.pink, width: 100, height: 120),
        Container(color: Colors.blue, width: 180, height: 150),
        Container(color: Colors.yellow, width: 80, height: 150),
        Container(color: Colors.purple, width: 150, height: 200),
        Container(color: Colors.lime, width: 80, height: 150),
        Container(color: Colors.orange, width: 150, height: 200),
      ],
    );
  }

  Widget _buildStack() {
    return Stack(
      alignment: Alignment.center,
      children: [
        Container(color: Colors.blue, width: 400, height: 300),
        Container(color: Colors.red, width: 300, height: 200),
        Container(color: Colors.purple, width: 200, height: 100),
        Positioned(
          right: 10,
          bottom: 10,
          child: Container(color: Colors.yellow, width: 150, height: 50),
        ),
      ],
    );
  }

  Widget _buildIconRow() {
    return Center(
      child: Row(
        children: [
          Container(color: Colors.pink, width: 50, height: 50),
          SizedBox(width: 10),
          Container(color: Colors.blue, width: 50, height: 50),
          SizedBox(width: 10),
          Container(color: Colors.amber, width: 50, height: 50),
          Spacer(),
          Container(color: Colors.purple, width: 50, height: 50),
        ],
      ),
    );
  }

  Widget _buildColumn() {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(color: Colors.pink, width: 180, height: 250),
            Container(color: Colors.lime, width: 150, height: 270),
            Container(color: Colors.blue, width: 140, height: 290),
            Container(color: Colors.amber, width: 160, height: 240),
            Container(color: Colors.purple, width: 180, height: 280),
          ],
        ),
      ),
    );
  }

  Widget _buildRow() {
    return SingleChildScrollView(
      physics: BouncingScrollPhysics(),
      scrollDirection: Axis.horizontal,
      child: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(color: Colors.pink, width: 280, height: 50),
            SizedBox(width: 20),
            Container(color: Colors.lime, width: 250, height: 70),
            SizedBox(width: 20),
            Container(color: Colors.blue, width: 240, height: 90),
            SizedBox(width: 20),
            Container(color: Colors.amber, width: 260, height: 40),
            SizedBox(width: 20),
            Container(color: Colors.purple, width: 280, height: 80),
          ],
        ),
      ),
    );
  }
}
