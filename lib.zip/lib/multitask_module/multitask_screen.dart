import 'package:flutter/material.dart';
import 'package:flutter_project/multitask_module/multitask_font_logic.dart';
import 'package:flutter_project/multitask_module/multitask_theme_logic.dart';
import 'package:provider/provider.dart';
import 'package:skeletonizer/skeletonizer.dart';
import 'package:flutter_project/multitask_module/api_service.dart';
import 'package:flutter_project/multitask_module/product_model.dart';



Widget skeletonLoader() {
  return Skeletonizer(
    child: ListView.builder(
      physics: BouncingScrollPhysics(),
      itemCount: 10,
      itemBuilder: (context, index) {
        return Card(
          child: ListTile(
            title: Text("some text some text some text some text"),
            subtitle: Container(
              color: Colors.grey,
              height: 300,
              width: double.maxFinite,
            ),
          ),
        );
      },
    ),
    );
}



class MultitaskScreen extends StatefulWidget {
  const MultitaskScreen({super.key});

  @override
  State<MultitaskScreen> createState() => _MultitaskScreenState();
}

class _MultitaskScreenState extends State<MultitaskScreen> {

  late Future<List<ProductModel>> _futureProductList;

  @override
  void initState() {
    super.initState();
    _futureProductList = ApiService.read();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Fake Product Screen")),
      body: _buildBody(),
      drawer: _buildDrawer(),
    );
  }


  Widget _buildDrawer() {
  final logo = 
    "https://i.pinimg.com/736x/6a/a9/61/6aa9617e53885e4010858e007ef97ebe.jpg";

  int themeIndex = context.watch<MultitaskThemeLogic>().themeIndex;

  return Drawer(
    child: ListView(
      children: [
      DrawerHeader(child: Icon(Icons.face, size: 100)),
      ListTile(
        leading: Icon(Icons.home),
        title: Text("Home"),
        onTap: (){
          Navigator.of(context).pop();
        },
      ),
      ListTile(
        leading: Icon(Icons.settings),
        title: Text("Settings"),
        onTap: (){
          Navigator.of(context).pop();
        },
      ),
      ListTile(
        leading: Icon(Icons.call),
        title: Text("Contact"),
        onTap: (){
          Navigator.of(context).pop();
        },
      ),
      Divider(),
      ExpansionTile(
        title: Text("Theme Color"),
        initiallyExpanded: true,
        children: [
          ListTile(
            leading: Icon(Icons.phone_android),
            title: Text("To System Mode"),
            onTap: () {
              context.read<MultitaskThemeLogic>().changeToSystem();
            },
            trailing: themeIndex == 0 ? Icon(Icons.check_circle): null,
          ),
          ListTile(
            leading: Icon(Icons.dark_mode),
            title: Text("To Dark Mode"),
            onTap: () {
              context.read<MultitaskThemeLogic>().changeToDark();
            },
            trailing: themeIndex == 1 ? Icon(Icons.check_circle): null,
          ),
          ListTile(
            leading: Icon(Icons.light_mode),
            title: Text("To Light Mode"),
            onTap: () {
              context.read<MultitaskThemeLogic>().changeToLight();
            },
            trailing: themeIndex == 2 ? Icon(Icons.check_circle): null,
          ),
        ],
      ),
      Divider(),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            onPressed: () {
              context.read<MultitaskFontLogic>().decrease();
            },
            icon: Icon(Icons.text_decrease_rounded),
          ),
          IconButton(
            onPressed: () {
              context.read<MultitaskFontLogic>().increase();
            },
            icon: Icon(Icons.text_increase_rounded),
          ),
        ],
      ),
      Divider(),
    ],
    ),
  );
}



  Widget _buildBody() {
    return RefreshIndicator(
      onRefresh: () async {
        setState(() {
          _futureProductList = ApiService.read();
        });
      },
      child: Center(
      child: FutureBuilder<List<ProductModel>>(
        future: _futureProductList,
        builder: (context, snapshot) {
          if(snapshot.hasError) {
            return _buildError(snapshot.error);
          }

          if(snapshot.connectionState == ConnectionState.done){
            return _buildListView(snapshot.data ?? []);
          }
          else{
            return skeletonLoader();
          }
        },
      ),
      ),
    );
  }

  Widget _buildError(Object? error) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error),
          Text(error.toString()),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                _futureProductList = ApiService.read();
              });
            },
            icon: Icon(Icons.refresh),
            label: Text("Retry"),
          ),
        ],
      ),
    );
  }

Widget _buildListView(List<ProductModel> items){
  return ListView.builder(
    physics: BouncingScrollPhysics(),
    itemCount: items.length,
    itemBuilder: (context, index){
      final item = items[index];
      return Card(
        child: ListTile(
          title: Text(item.title),
          subtitle: Image.network(item.image),
        ),
      );
    },
  );
}

}