import 'package:flutter/material.dart';
import 'package:flutter_project/multitask_module/multitask_app.dart';
import 'package:flutter_project/multitask_module/multitask_font_logic.dart';
import 'package:flutter_project/multitask_module/multitask_splash_screen.dart';
import 'package:flutter_project/multitask_module/multitask_theme_logic.dart';
import 'package:flutter_project/practice_inclass/font_logic.dart';
import 'package:flutter_project/practice_inclass/theme_logic.dart';
import 'package:provider/provider.dart';


Widget multitaskProvider() {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider( create: (context) => MultitaskFontLogic()),
      ChangeNotifierProvider(create: (context) => MultitaskThemeLogic())
    ],
    child: MultitaskSplashScreen(),
  );
}
