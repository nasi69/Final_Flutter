

  List<String> actorList = [
    "https://www.mercurynews.com/wp-content/uploads/2016/09/20160513_074630_leonardo_dicaprio_24734_13519.jpg?w=640",
    "https://img.buzzfeed.com/buzzfeed-static/static/2015-03/5/16/tmp/webdr03/e4f4ad1063f92e26722c1a0394c8fcd0-1.jpg?fill=625:625",
    "https://www.nickiswift.com/img/gallery/actors-who-didnt-get-famous-until-they-were-older-upgrade/intro-1503329975.jpg",
    "https://images.saymedia-content.com/.image/t_share/MTc2MjYzNDgxODc1MTEzMTUw/famous-and-best-english-actors-and-actresses.jpg",
    "https://www.thefashionisto.com/wp-content/uploads/2023/09/Brad-Pitt-Blonde-Hair-1.jpg",
    "https://150074292.v2.pressablecdn.com/wp-content/uploads/2021/12/Will-Smith-768x1103.jpg",
    "https://www.famousafricanamericans.org/images/morgan-freeman.jpg",
    "https://ciowomenmagazine.com/wp-content/uploads/2024/01/1.1-Scarlett-Johansson-Source-Refinery29.jpg",
  ];

    List<String> imageList = [
    "https://img.etimg.com/thumb/width-1600,height-900,imgsize-25450,resizemode-75,msid-119557011/news/international/us/entertainment/final-destination-bloodlines-when-will-it-release-in-theaters-heres-release-date-trailer-cast-and-plot.jpg",
    "https://resizing.flixster.com/-XZAfHZM39UwaGJIFWKAE8fS0ak=/v3/t/assets/p194483_p_v8_aa.jpg",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRH4itR4T2MqrmfkfZxW4VzFjy1gs6esw2vMw&s",
    "https://m.media-amazon.com/images/M/MV5BNjIwZWY4ZDEtMmIxZS00NDA4LTg4ZGMtMzUwZTYyNzgxMzk5XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg",
  ];