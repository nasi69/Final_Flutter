import 'package:flutter/material.dart';
import 'package:flutter_project/readgame_module/readgame_provider.dart';

void main() {
  runApp(readgameProvider());
}
