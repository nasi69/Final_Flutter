import 'package:flutter/material.dart';
import 'package:flutter_project/readgame_module/readgame_font_logic.dart';
import 'package:flutter_project/readgame_module/readgame_splash_screen.dart';
import 'package:flutter_project/readgame_module/readgame_theme_logic.dart';
import 'package:provider/provider.dart';


Widget readgameProvider() {
  return MultiProvider(
    providers: [
      ChangeNotifierProvider( create: (context) => ReadgameFontLogic()),
      ChangeNotifierProvider(create: (context) => ReadgameThemeLogic())
    ],
    child: ReadgameSplashScreen(),
  );
}
