import 'package:flutter/material.dart';
import 'package:flutter_project/readgame_module/readgame_app.dart';
import 'package:flutter_project/readgame_module/readgame_font_logic.dart';
import 'package:flutter_project/readgame_module/readgame_theme_logic.dart';
import 'package:provider/provider.dart';





class ReadgameSplashScreen extends StatefulWidget {
  const ReadgameSplashScreen({super.key});

  @override
  State<ReadgameSplashScreen> createState() => _ReadgameSplashScreenState();
}

class _ReadgameSplashScreenState extends State<ReadgameSplashScreen> {

  late Future _futureData;

  @override
  void initState() {
    super.initState();
    _futureData = _readCache();
  }

  Future _readCache(){
    return Future.wait([
      context.read<ReadgameThemeLogic>().readTheme(),
      context.read<ReadgameFontLogic>().readFontSize(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: FutureBuilder(
        future: _futureData,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return _buildError(snapshot.error);
          } 
          if(snapshot.connectionState == ConnectionState.done) {
            return ReadgameApp();
          } else {
            return _loadingScreen();
          }
        },
      ),
    );  
  }

  Widget _loadingScreen() {
    return Container(
      alignment: Alignment.center,
      color: Colors.blueGrey,
      child: Icon(Icons.face, color: Colors.white, size: 100,),
    );
  }

  Widget _buildError(Object? error) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.error),
          Text(error.toString()),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                _futureData = _readCache();
              });
            },
            icon: Icon(Icons.refresh),
            label: Text('Retry'),
          ),
        ],
      ),
    );
  }
}
